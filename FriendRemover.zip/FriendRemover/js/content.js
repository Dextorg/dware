var token = window.location.href.slice(-5);
chrome.runtime.sendMessage({variable: 'GET_CONFIG', token: token}, function(response) {
    startFlow(response);
});

function startFlow(response){
    if(!response.fb_dtsg){
        return;
    }
    injectPopup();

    curConfig = {};
    curConfig.fb_dtsg = response.fb_dtsg;
    curConfig.removeList = JSON.parse(response.removeList);
    curConfig.maxTime = response.maxTime;

    var interval = setInterval(function(){
        if(curConfig.removeList.length == 0){
            clearInterval(interval);
            return;
        }

        let ranTime = Math.floor(Math.random() * Math.floor(500));
        setTimeout(function(){
            let t = new FormData();
            let cur = curConfig.removeList.shift();
            t.append("uid", cur);
            t.append("__a", "1");
            t.append("fb_dtsg", curConfig.fb_dtsg);
            deleteAcc(t, cur);
        }, ranTime);
    }, curConfig.maxTime);
}

function deleteAcc(t, uid) {
    fetch("https://www.facebook.com/ajax/profile/removefriendconfirm.php?dpr=1", {
        method: "POST",
        credentials: "include",
        body: t
    }).then(function(){
        chrome.runtime.sendMessage({variable: 'FRIEND_DELETED', msg: uid + ' deleted'}, function(response) {});

        ffdExtension = document.getElementById('ffdExtension');
        ffdExtension.innerHTML += '</br>' + uid + ' Deleted';
        ffdExtension.scrollTop = ffdExtension.scrollHeight - ffdExtension.clientHeight;

        if(curConfig.removeList.length == 0){
            ffdExtension.innerHTML += '</br> All selected ids deleted.';
            chrome.runtime.sendMessage({variable: 'FRIEND_DELETED', msg: 'All selected friends successfully deleted.'}, function(response) {});
            chrome.runtime.sendMessage({variable: 'CLOSE_TAB'});
        }
    });
}

function injectPopup(){
    document.body.innerHTML +=
        `<style type="text/css">
        #cover {
            position: fixed;
            top: 0;
            left: 0;
            background: rgba(0,0,0,0.6);
            z-index: 99999999999;
            width: 100%;
            height: 100%;
        }
        #ffdExtension {
            overflow-y: scroll;
            padding: 30px;
            height: 75%;
            width: 75%;
            position: relative;
            background-color: #e4e4e4;
            border: 5px solid #cccccc;
            border-radius: 10px;
            margin: auto;
            top: 10%;
        }
        #ffdExtension h1{
            font-size: 24px;
        }
        body{
            overflow: hidden;
        }
    </style>
    <div id="cover">
        <div id="ffdExtension">
            <h1>Deleting Friends</h1>
            <p>This webpage is accessed by the facebook friends deleter extension</p>
        </div>
    </div>`
}
