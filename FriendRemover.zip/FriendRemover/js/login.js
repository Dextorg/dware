let appUrl = 'https://dware.everdealer.com/fm/auth';

const c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$('#login').submit(function (e) {
    e.preventDefault();
    let email = $('#email').val();
    let password = $('#password').val();
    let token = Array.from({length: 5}, _ => c[Math.floor(Math.random() * c.length)]).join('');

    if ('' === email || '' === password) {
        alert('please provide Email/Password');
        return false;
    }
    $.post(appUrl,
        {userEmail: email, userPassword: password, signIn: true, appVersion: 1}).then(function (res) {
        if (res["processSucceed"]) {
            localStorage.setItem('email', email);
            localStorage.setItem('login-token', token);
            localStorage.setItem('session-token', true);
            createCookie("lastlogincheck", "true", 5);
            location.href = 'main.html';
        } else {
            $('#email').val('');
            $('#password').val('');
            alert('Email/Password is wrong');
        }
    });
});

$('.btn-forgot-password').click(function (e) {
    e.preventDefault();
    let email = $('#email').val();
    if ('' === email) {
        alert('please provide Email');
        return false;
    }
    $.post(appUrl, {userEmail: email, updatePassword: true}).then(function (res) {
        $('#login').replaceWith('<h4>Your new password sent on your registered email id.</h4>');
    });
});

function createCookie(name, value, minutes) {
    if (minutes) {
        var date = new Date();
        date.setTime(date.getTime() + (minutes * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    } else {
        var expires = "";
    }
    document.cookie = name + "=" + value + expires + "; path=/";
}
