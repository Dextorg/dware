let appUrl = 'https://dware.everdealer.com/fm/auth';

if (!localStorage.getItem('session-token')) {
    location.href = 'login.html'
}

$('#settings').submit(function (e) {
    e.preventDefault()
    let maxFriendQueue = $('#max-friend-queue').val();
    let reqTime = $('#time-between-two-reqs').val();

    if (maxFriendQueue < 1) {
        alert('please provide number of max friend in queue greater than 0');
        return;
    }

    if (reqTime < 1000) {
        alert('please provide time between two requests greater than 1000 milliseconds');
        return;
    }

    localStorage.setItem('max-friend-queue', maxFriendQueue);
    localStorage.setItem('time-between-two-reqs', reqTime);
    $('.btn-submit').replaceWith('<p class="mt-3 text-primary">Settings saved</p>');
});

$('.btn-change-pass').click(function () {
    $('#settings').addClass('d-none');
    $('#new-pass').removeClass('d-none');
});

$('.btn-logout').click(function () {
    localStorage.clear();
    location.reload();
});

$('#new-pass').submit(function (e) {
    e.preventDefault();
    // let oldPass = $('#old_password').val();
    let newPass = $('#new_password').val();
    let email = localStorage.getItem('email');

    if (!newPass) {
        alert('please provide old and new password');
        return;
    }

    $.post(appUrl, {userEmail: email, newPassword: newPass, updatePassword: true}).then(function (res) {
        if (res["processSucceed"]) {
            $('#new-pass').replaceWith('<h4>Your new password successfully changed.</h4>');
        } else {
            alert('old password is incorrect.');
        }
    });
});

$('#max-friend-queue').val(localStorage.getItem('max-friend-queue') || 50);
$('#time-between-two-reqs').val(localStorage.getItem('time-between-two-reqs') || 4000);
