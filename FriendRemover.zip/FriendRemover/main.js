let appUrl = 'https://dware.everdealer.com/fm/auth';
if (!localStorage.getItem('session-token')) {
    location.href = 'login.html'
}

if (document.cookie.indexOf('lastlogincheck') === -1) {
    $.post(appUrl,
        {userEmail: localStorage.getItem('email'), appVersion: '1', checkUser: true})
        .then(function (res) {
            if (!res["processSucceed"]) {
                localStorage.removeItem('session-token');
                location.href = 'login.html';
            } else {
                createCookie("lastlogincheck", "true", 5);
            }
        });
}

function createCookie(name,value,minutes) {
    if (minutes) {
        var date = new Date();
        date.setTime(date.getTime()+(minutes*60*1000));
        var expires = "; expires="+date.toGMTString();
    } else {
        var expires = "";
    }
    document.cookie = name+"="+value+expires+"; path=/";
}

(function(){
    function remove(array, element) {
        return array.filter(el => el !== element);
    }

    var allFriends = {};
    var friends = [];
    var config = {};
    var removeList = [];

    function getAccessToken(data) {
        let d = $.Deferred();
        let o = data.match(/accessToken\\":\\"([^\\]+)/);
        let t = {};
        if(null === o){
            alert('error in fetching the access token may be you are not logged in!');
            d.reject();
            return d.promise();
        }
        config = {};

        config.access_token = o[1];
        let n = data.match(/{\\"dtsg\\":{\\"token\\":\\"([^\\]+)/);
        config.dt = n[1];
        let r = data.match(/\\"NAME\\":\\"([^"]+)/);
        r = r[1].slice(0, -1).replace(/\\\\/g, "\\");
        r = decodeURIComponent(JSON.parse(`"${r}"`));
        config.name = r;

        chrome.storage.local.set({'config': JSON.stringify(config)},function(){
            d.resolve();
        });
        return d.promise();
    }

    function start() {
        chrome.storage.local.get('config', function(res){
            config = res.config ? JSON.parse(res.config) : '';
            if(!config){
                let url = 'https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed';
                $.ajax(url).then(function(response){
                    getAccessToken(response).then(function(){
                        $('#inactive').click();
                    });
                })
            }else{
                $('#inactive').click();
            }
        });
    }

    function getAllFriends(offset, limit){
        let d = $.Deferred();
        $.ajax({url: "https://graph.facebook.com/fql",method: 'get',
            error: function(res){alert('error in fetching friend list. Facebook Error: ' + (res.responseJSON ? res.responseJSON.error.message: ''))},
            data:
                {q: `SELECT uid, name, pic_big FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1 = me()) limit ${offset || 0},${limit || 100}`, access_token: config.access_token}}).then(
            function (response){
                allFriends['total'] = response.data;
                getComments().then(function(){
                    d.resolve();
                })
            }
        );
        return d.promise();
    }

    function getComments(){
        let d = $.Deferred();
        $.ajax({url: "https://graph.facebook.com/fql",method: 'get',data: {q: `SELECT fromid, text, time, post_id FROM comment WHERE post_id in (SELECT post_id FROM stream WHERE source_id = me())`,access_token: config.access_token}}).then(
            function (response){
                let coms = response.data;
                for(let c in coms){
                    if(coms[c]['text'] != ''){
                        friends[coms[c]['fromid']] = friends[coms[c]['fromid']] || [];
                        dateObj = new Date(coms[c]['time'] * 1000);
                        friends[coms[c]['fromid']]['comment'] = coms[c]['text'] + "   " + dateObj.toUTCString();
                    }
                }

                $.ajax({url: "https://graph.facebook.com/fql",method: 'get',data: {q: `SELECT user_id, object_id, post_id, object_type FROM like WHERE post_id in(SELECT post_id FROM stream WHERE source_id = me())`, access_token: config.access_token}}).then(
                    function(response){
                        let coms = response.data;
                        for(let c in coms){
                            friends[coms[c]['user_id']] = friends[coms[c]['user_id']] || [];
                            friends[coms[c]['user_id']]['like'] = coms[c]['post_id'];
                        }
                    }
                )

                d.resolve();
            }
        );
        return d.promise();
    }

    function getActiveFriends(offset, limit){
        let d = $.Deferred();
        getAllFriends().then(function(){
            $.ajax({url: "https://graph.facebook.com/fql",method: 'get',
                error: function(res){alert('error in fetching friend list. Facebook Error: ' + (res.responseJSON ? res.responseJSON.error.message: ''))},
                data:
                    {q: `SELECT uid, name, pic_big FROM user WHERE (uid IN (SELECT fromid FROM comment WHERE post_id in (SELECT post_id FROM stream WHERE source_id = me())) or uid in (SELECT user_id FROM like WHERE post_id in(SELECT post_id FROM stream WHERE source_id = me()))) and uid IN (SELECT uid2 FROM friend WHERE uid1 = me()) limit ${offset || 0}, ${limit || 100}`,access_token: config.access_token}}).then(
                function (response){
                    allFriends['active'] = response.data;
                    d.resolve();
                }
            );
        });
        return d.promise();
    }

    function getInActiveFriends(offset, limit){
        let d = $.Deferred();
        getActiveFriends().then(function(){
            let inactive = [...allFriends['total']];
            for(let i in allFriends['active']){
                for(let j in inactive){
                    if(inactive[j]['uid'] == allFriends['active'][i]['uid']){
                        inactive.splice(j, 1);
                    }
                }
            }
            allFriends['inactive'] = inactive.slice(offset, offset+limit);
            d.resolve();
        });
        return d.promise();
    }

    function injectFriends(data){
        removelist = [];
        $('#friendsList').empty();
        for (let i in data) {
            let link = friends[data[i].uid] ? friends[data[i].uid]['like'] || '':'';
            let comment = friends[data[i].uid] ? friends[data[i].uid]['comment'] || '':'';
            let list = `
                <div class='col-1 bottom-margin'>
                    <div class="mycard" data-uid='${data[i].uid}'>
                        <img src="${data[i].pic_big}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-title mb-0">${data[i].name}</p>
                            <a href='https://facebook.com/${data[i].uid}' class="card-title" target='_blank'>View Profile</a>
                        </div>
                    </div>
                </div>
            `;
            removelist.push(list);
        }

        $("#friendsList").append(removelist.join(""));
        $('#count_friends').text(removelist.length);
    }

    function appendFriends(data){
        removelist = [];
        for (let i in data) {
            let link = friends[data[i].uid] ? friends[data[i].uid]['like'] || '':'';
            let comment = friends[data[i].uid] ? friends[data[i].uid]['comment'] || '':'';
            let list = `
                <div class='col-1 bottom-margin'>
                    <div class="mycard" data-uid='${data[i].uid}'>
                        <img src="${data[i].pic_big}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-title mb-0">${data[i].name}</p>
                            <a href='https://facebook.com/${data[i].uid}' class="card-title" target='_blank'>View Profile</a>
                        </div>
                    </div>
                </div>
            `;
            removelist.push(list);
        }

        $("#friendsList").append(removelist.join(""));
    }

    start()

    $('#total').click(function(){
        removeList = [];
        $("#delete-count").text(removeList.length);
        $('#friendsList').html('Loading');
        $('#pagination-btn').css('display','none');

        getAllFriends(0,100).then(function(){
            injectFriends(allFriends['total']);
            $('#pagination').attr('fn','getAllFriends');
            $('#pagination').attr('friend_type','total');
            $('#pagination').attr('offset','100');
            $('#pagination-btn').css('display','inline-block');
        });
    });
    $('#active').click(function(){
        removeList = [];
        $("#delete-count").text(removeList.length);
        $('#friendsList').html('Loading');
        $('#pagination-btn').css('display','none');

        getActiveFriends(0,100).then(function(){
            injectFriends(allFriends['active']);
            $('#pagination').attr('fn','getActiveFriends');
            $('#pagination').attr('friend_type','active');
            $('#pagination').attr('offset','100');
            $('#pagination-btn').css('display','inline-block');
        });
    });
    $('#inactive').click(function(){
        removeList = [];
        $("#delete-count").text(removeList.length);
        $('#friendsList').html('Loading');
        $('#pagination-btn').css('display','none');

        getInActiveFriends(0,100).then(function(){
            injectFriends(allFriends['inactive']);
            $('#pagination').attr('fn','getInActiveFriends');
            $('#pagination').attr('friend_type','inactive');
            $('#pagination').attr('offset','100');
            $('#pagination-btn').css('display','inline-block');
        });
    });

    $('#pagination-btn').click(function(){
        $(this).attr('disabled', 'disabled');
        $('#pagination-btn').text('Loading');

        eval($('#pagination').attr('fn') + '(' + $('#pagination').attr('offset') +`, 100).then(function(){
            appendFriends(allFriends['${$('#pagination').attr('friend_type')}']);
            $('#pagination').attr('offset', ${(+$('#pagination').attr('offset') + 100)});
            if(allFriends['${$('#pagination').attr('friend_type')}'] && allFriends['${$('#pagination').attr('friend_type')}'].length == 0){
                $('#pagination-btn').css('display','none');
            }
            $('#pagination-btn').removeAttr('disabled');
            $('#pagination-btn').text('Load More');               
        })`);
    });

    $('#friendsList').on('click', '.mycard', function(){
        let uid = $(this).data('uid');
        if($(this).hasClass('selected')){
            removeList = remove(removeList, uid);
        }else{
            if(removeList.length + 1 > (parseInt(localStorage.getItem('max-friend-queue')) || 50)){
                alert('Max Queue limit exceeded.');
                return false;
            }
            removeList.push(uid);
        }
        $(this).toggleClass('selected');
        $("#delete-count").text(removeList.length);
    });

    $('#friendsList').on('click', '.stop-propagation', function(e){
        e.stopPropagation();
    });

    const c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    function getToken(){
        return Array.from({length:5}, _ => c[Math.floor(Math.random()*c.length)]).join('');
    }

    chrome.runtime.onMessage.addListener(
        function(request, sender, sendResponse) {
            if (request.type == "FRIEND_DELETED_RES"){
                $('#popup-content').append('</br>' + request.data.msg);
                ffdExtension = document.getElementById('popup-content');
                ffdExtension.scrollTop = ffdExtension.scrollHeight - ffdExtension.clientHeight;
            }
            return true;
        }
    );


    $("#delete").on('click', function (e) {
        if (removeList.length == 0) {
            return;
        }
        var result = confirm(`Are you sure want to delete ${removeList.length} friends!`);
        if (result == true) {
            $('.overlay').addClass('active');

            let deltime = localStorage.getItem('time-between-two-reqs') || 4000;

            chrome.runtime.sendMessage(
                {variable: 'SET_CONFIG',
                    fb_dtsg: config.dt,
                    removeList: JSON.stringify(removeList),
                    maxTime: deltime,
                    token: getToken()}, function(response) {}
            );
        }
    });

    $('.close').on('click', function(){
        $('.overlay').removeClass('active');
        location.reload();
    });

    $('#del-acc-token').on('click', function(){
        chrome.storage.local.clear();
        location.reload();
    });
}());
