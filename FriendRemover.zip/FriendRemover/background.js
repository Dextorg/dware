chrome.runtime.onStartup.addListener(function () {
    chrome.storage.local.clear();
})

function openOrFocusOptionsPage() {
    isLogin = localStorage.getItem('session-token');

    if (isLogin) {
        loginOrMain = 'main.html';
    } else {
        loginOrMain = 'login.html';
    }
    var optionsUrl = chrome.extension.getURL(loginOrMain);

    chrome.tabs.query({}, function (extensionTabs) {
        var found = false;
        for (var i = 0; i < extensionTabs.length; i++) {
            if (optionsUrl == extensionTabs[i].url) {
                found = true;
                chrome.tabs.update(extensionTabs[i].id, {"selected": true});
            }
        }
        if (found == false) {
            chrome.tabs.create({url: loginOrMain});
        }
    });
}

chrome.extension.onConnect.addListener(function (port) {
    var tab = port.sender.tab;
    port.onMessage.addListener(function (info) {
        var max_length = 1024;
        if (info.selection.length > max_length)
            info.selection = info.selection.substring(0, max_length);
        openOrFocusOptionsPage();
    });
});

chrome.browserAction.onClicked.addListener(function (tab) {
    openOrFocusOptionsPage();
});

var curConfig = {};

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.variable === 'SET_CONFIG') {
        curConfig.fb_dtsg = request.fb_dtsg;
        curConfig.removeList = request.removeList;
        curConfig.maxTime = request.maxTime;
        curConfig.token = request.token;
        curConfig.tabid = sender.tab.id;

        chrome.tabs.create({url: 'https://www.facebook.com/?asdfjkfds' + request.token, active: false}, function (tab) {
            curConfig.tab = tab;

            if (chrome.runtime.lastError) {
                throw(new Error(chrome.runtime.lastError));
            } else {
                sendResponse(true);
            }
        });
        return true;
    } else if (request.variable === 'GET_CONFIG') {
        if (request.token == curConfig.token) {
            curConfig.token = '';
            sendResponse(curConfig);
        } else {
            sendResponse({});
        }
    } else if (request.variable === 'FRIEND_DELETED') {
        chrome.tabs.sendMessage(curConfig.tabid, {
            type: 'FRIEND_DELETED_RES',
            data: {msg: request.msg}
        }, function (response) {
        });
    } else if (request.variable === 'CLOSE_TAB') {
        chrome.tabs.remove(sender.tab.id, function () {
        });
    }
});
