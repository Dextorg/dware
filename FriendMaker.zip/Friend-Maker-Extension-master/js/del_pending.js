var port = chrome.extension.connect({
    name: "Popup-Background"
});
var facebookURL = /^(http|https):\/\/(www.)*(facebook)(\.com)/;
var redirectPage = "nopopup.html";
$(function () {

    var auth = new Auth();
    var popup = new PopUp();
    // auth.deleteStorage();
    // Check Auth
    popup.showCheckPopup();
    auth.checkAuthStatus();

    chrome.storage.local.get("emailID", function (items) {
        console.log(items);
        $(".loggedInAs").text(items.emailID);
    });

    // // Action if Stop Request Triggered
    $("#delPending").click(function () {
        let interval = $("#interval_time").val() * 1000;
        if (interval)
            popup.getTab()
                .then(tab => {
                    var payloads = {
                        action: "delPending",
                        payload: {
                            tabID: tab.id,
                            interval: interval
                        }
                    };
                    popup.sendRequest(payloads);
                })
                .catch(e => {
                    console.log(e);
                });
        else
            alert('input Interval Time')
        // chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        //   var payloads = {
        //     action: "stopScript",
        //     payload: {
        //       tabID: tabs[0].id
        //     }
        //   };
        //   popup.sendRequest(payloads);
        // });
    });

    $("#logout").click(function () {
        auth.deleteStorage();
        window.close();
    });

});

/** START -- Popup related class */
class PopUp extends Communication {
    constructor() {
        super();
    }

    showCheckPopup() {
        chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
            const currentUrl = tabs[0].url;
            if (facebookURL.test(currentUrl)) {
                console.log('True');
            } else {
                // console.log('False');
                window.location.href = "./" + redirectPage;
            }

        });
    }

    getTab() {
        return new Promise((resolve, reject) => {
            try {
                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    resolve(tabs[0]);
                });
            } catch (e) {
                reject({errorType: 'CATCH_BLOCK_GET_TAB', msg: e.message})
            }
        })
    }
}

/** END -- Popup related class */

