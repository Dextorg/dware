var port = chrome.extension.connect({
  name: "Friends-Background"
});

$(function() {
  var auth = new Auth();
  var popup = new SuggestedFriends();
  
  auth.checkAuthStatus(); // Check Auth
  popup.retrieveFormData(); // Retrive previous form data
  popup.getTab()
  .then(tab => popup.setStatus(tab))
  .catch(e => {
    console.log(e);
  }); // Enable Disable Run Button

  // Fetching saved email id
  chrome.storage.local.get("emailID", function(items) {
    console.log(items);
    $(".loggedInAs").text(items.emailID);
  });

  // Logout function
  $("#logout").click(function() {
    auth.deleteStorage();
    window.close();
  });
  
  // Initialization
  // $(".specificType").click(function() {
  //   if ($("#specific_y").is(":checked")) {
  //     $("#specificIndex").removeAttr("disabled");
  //     $(".memberIndex").slideDown();
  //   } else {
  //     $("#specificIndex").attr("disabled", "disabled");
  //     $(".memberIndex").slideUp();
  //     $(".siMsg").css("display", "none");
  //   }
  // });

  $(".reqType").click(function() {
    if ($("#reqType_l").is(":checked")) {
      $("#numberOfReq").removeAttr("disabled");
      $(".noOfReqBlock").slideDown();
    } else {
      $("#numberOfReq").attr("disabled", "disabled");
      $(".noOfReqBlock").slideUp();
    }
  });

  // $("#specificIndex").blur(function() {
  //   if ($.trim($(this).val()) == "") {
  //     $(".siMsg").css("display", "block");
  //   } else {
  //     $(".siMsg").css("display", "none");
  //   }
  // });
  // Initialization

  // // Action if Stop Request Triggered
  $("#stopScript").click(function(){
    popup.getTab()
    .then(tab => popup.enableRun(tab))
    .then(bool => {
      console.log(bool);
    }).catch (e => {
      console.log(e);
    });
    const payload = {
        action: "stopSuggestionScript"
    };
    popup.sendRequest(payload);
  });

  $("form").submit(function(e) {
    e.preventDefault();
    const data = $(this).serializeArray();
    const serializedData = popup.serializeFormData(data);
    const payload = {
      action: "sendSuggestionReq",
      payload: serializedData
    };
    popup.getTab()
    .then(tab => popup.disableRun(tab))
    .then(bool => {
      console.log(bool);
    }).catch (e => {
      console.log(e);
    });
    popup.saveFormData(serializedData);
    popup.sendRequest(payload);
    // sendRequest(serializedData);
  });
});

/** START -- Popup related class */
class SuggestedFriends extends Communication {
  constructor() {
    super();
  }

  retrieveFormData() {
    chrome.storage.sync.get("suggestedData", function(items) {
      console.log("Saved Suggested Data",items);
      if (items.suggestedData) {
        $("#loadFormData").show();
        $(".interval option[value=" + items.suggestedData.interval + "]").attr(
          "selected",
          "selected"
        );

        $("#gtlt option[value=" + items.suggestedData.gtlt + "]").attr("selected","selected");
        
        if (items.suggestedData.mutual) {
          $("#mutual").val(parseInt(items.suggestedData.mutual));
        }

        if (items.suggestedData.reqType == "1") {
          $("#reqType_i").removeAttr("checked");
          $("#reqType_l").attr("checked", "checked");
          $(".numberOfReq").val(items.suggestedData.numberOfReq);
        } else {
          $("#reqType_l").removeAttr("checked");
          $("#reqType_i").attr("checked", "checked");
          $(".noOfReqBlock").css("display", "none");
        }

        // if (items.suggestedData.specific == "1") {
        //   $("#specific_n").removeAttr("checked");
        //   $("#specific_y").attr("checked", "checked");
        //   $(".memberIndex").css("display", "block");
        //   $("#specificIndex").val(items.suggestedData.specificIndex);
        // } else {
        //   $("#specific_y").removeAttr("checked");
        //   $("#specific_n").attr("checked", "checked");
        //   $(".memberIndex").css("display", "none");
        //   $("#specificIndex").attr('disabled','disabled');
        // }
      } else {
        $("#loadFormData").hide();
      }
    });
  }

  saveFormData(data) {
    console.log("Suggested Data",data);
    chrome.storage.sync.set({ suggestedData: { ...data } }, function() {
      console.log("Saved");
    });
  }

  disableRun(tab) {
    // chrome.storage.sync.set({ FriendListBtnStatus: 'disable' }, function() {
    //   console.log("Disabled");
    // });
    // $("#sendRQBtn").attr('disabled', 'disabled');
    // $("#stopScript").removeAttr('disabled');

    return new Promise((resolve, reject) => {
      try {
        var arr = {
          tabID: tab.id,
          status: 'disable'
        };
        chrome.storage.local.get({sf: []}, function(data) {
          console.log('Disable Run', data);
          if(data.sf.length) {
            var group = data.sf;
            var index = data.sf.findIndex(el => {
              return el.tabID == tab.id;
            });
            if (index < 0) {
              group.push(arr);
            } else {
              group[index] = arr;
            }
            chrome.storage.local.set({sf: group}, function() {
              $("#sendRQBtn").css('display', 'none');
              $("#stopScript").css('display','block');
              resolve(true);
            });
          } else {
            chrome.storage.local.set({sf: [arr]}, function() {
              $("#sendRQBtn").css('display', 'none');
              $("#stopScript").css('display','block');
              resolve(true);
            });
          }
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_DISABLE_RUN', msg: e.message});
      }
    });
  }

  enableRun(tab) {
    // chrome.storage.sync.set({ FriendListBtnStatus: 'active' }, function() {
    //   console.log("Activated");
    // });
    // $("#sendRQBtn").removeAttr('disabled');
    // $("#stopScript").attr('disabled', 'disabled');
    return new Promise((resolve, reject) => {
      try {
        console.log("Stop pressed",tab.id);
        chrome.storage.local.get({sf: []}, function(data) {
          // var newGroup = data.group.find(el => {
          //   return el.tabID == tab.id;
          // });
          var newGroupMember = [];
          for(var i=0;i<data.sf.length;i++){
            // console.log("TID", data.sf[i].tabID);
            if (data.sf[i].tabID !== tab.id) {
              newGroupMember.push(data.sf[i]);
            }
          }
          chrome.storage.local.set({sf: newGroupMember}, function() {
            $("#sendRQBtn").css('display','block');
            $("#stopScript").css('display','none');
            resolve(true);
          });
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_ENABLE_RUN', msg: e.message});
      }
    });
  }

  setStatus(tab) {
    // chrome.storage.sync.get("FriendListBtnStatus", function(item) {
    //   console.log(item);
    //   if (item.FriendListBtnStatus == 'disable') {
    //     $("#sendRQBtn").attr('disabled', 'disabled');
    //     $("#stopScript").removeAttr('disabled');
    //   } else {
    //     $("#sendRQBtn").removeAttr('disabled');
    //     $("#stopScript").attr('disabled', 'disabled');
    //   }
    // });
    chrome.storage.local.get({sf: []}, function(data) {
      console.log(data);
      var status = false;
      // console.log(tab.id);
      for(var i=0;i<data.sf.length;i++){
        if (data.sf[i].tabID == tab.id) {
         status = true;
        }
      }
      if (status) {
        $("#sendRQBtn").css('display','none');
        $("#stopScript").css('display','block');
      } else {
        $("#sendRQBtn").css('display','block');
        $("#stopScript").css('display','none');
      }
    });
  }

  getTab() {
    return new Promise((resolve, reject) => {
      try {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
          resolve(tabs[0]);
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_GET_TAB', msg: e.message})
      }
    })
  }

  serializeFormData(data) {
    // console.log("Data before serialize",data);
    const formData = {};
    // Pushing this form data into a single object
    $.each(data, function(index, val) {
      if (val.name !== "keywords") {
        formData[val.name] = val.value;
      } else {
        if(val.value) {
          var keywords = val.value;
          formData[val.name] = keywords.split(",");
        } else {
          formData[val.name] = [];
        }
      }
    });
    return formData;
  }
}
/** END -- Popup related class */
