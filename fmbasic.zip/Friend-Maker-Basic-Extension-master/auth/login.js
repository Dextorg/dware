var regexURLs = [
    {
        regex: /^(http|https):\/\/(www.)*(facebook)(\.com)\/[a-z0-9.A-Z]{2,}\/friends/,
        page: "friends.html"
    },
    {
        regex: /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups\/members/,
        page: "popup.html"
    }
];
var redirectPage = "popup.html";

function reset_password(email) {
    fetch("https://portal.dwarelab.com/ext/users/reset_password/Friend%20Maker%20Basic", {
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({email: email}) // body data type must match "Content-Type" header
    })
        .then(response => response.json())
        .then(res => {
            if (res.http_code === 200) {
                // this.showExtDash();
                $(".successMsg")
                    .css("display", "block")
                    .text("Please Check your email to get the new Password");
                setTimeout(function () {
                    $(".successMsg").slideUp();
                    window.close();
                }, 2000);
            } else {
                $(".errMsg")
                    .css("display", "block")
                    .text(res.msg);
                setTimeout(function () {
                    $(".errMsg").slideUp();
                }, 2000);
            }
        })
        .catch(err => {
            console.log(err.message);
        });
}

$(function () {
    const auth = new LoginAuth(regexURLs, redirectPage);
    // Initialization
    $("#login").click(function () {
        // alert("hello");
        var email = $("#email").val();
        var password = $("#password").val();
        auth.authRemote(email, password);
    });
    $("#forget_password").click(function () {
        var email = $("#email").val();
        if (email)
            reset_password(email);
        else
            $(".errMsg")
                .css("display", "block")
                .text("Enter your email");
        setTimeout(function () {
            $(".errMsg").slideUp();
        }, 2000);
    })
    // deleteStorage();
    // checkAuthStatus();

    // port.postMessage({joke: "Knock knock"});
});

class LoginAuth {

    constructor(regex, redirect) {
        this.regexURLs = regex;
        this.redirectPage = redirect;
        this.authRemote = this.authRemote.bind(this);
    }

    authRemote(email, password) {
        // console.log(email);
        fetch("https://portal.dwarelab.com/ext/users/login/Friend%20Maker%20Basic", {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, cors, *same-origin
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({email: email, password: password}) // body data type must match "Content-Type" header
        })
            .then(response => response.json())
            .then(res => {
                if (res.http_code === 200) {
                    if (res.accessToken) {
                        this.saveAccessToken(res.accessToken, email);
                        // this.showExtDash();
                        window.close();
                    }
                } else {
                    $(".errMsg")
                        .css("display", "block")
                        .text(res.msg);
                    setTimeout(function () {
                        $(".errMsg").slideUp();
                    }, 2000);
                }
            })
            .catch(err => {
                console.log(err.message);
            });
    }

    showExtDash() {
        console.log("In Show Ext Dash");
        chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
            const currentUrl = tabs[0].url;
            // console.log("Current Tab", tabs[0].url);
            // console.log("Test URL", regexURLs[0].regex);
            // console.log(regexURLs[1].regex.test(tabs[0].url));
            const regexMatch = this.regexURLs.filter(url => {
                console.log(url.regex.test(currentUrl));
            });
            console.log(regexMatch);
            window.location.href = "../" + regexMatch[0].page;
        });
    }

    saveAccessToken(data, email) {
        chrome.storage.local.set({accessToken: data}, function () {
            console.log("Saved");
        });
        chrome.storage.local.set({emailID: email}, function () {
            console.log("Saved");
        });
    }
}
