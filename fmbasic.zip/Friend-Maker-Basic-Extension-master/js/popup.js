var port = chrome.extension.connect({
  name: "Popup-Background"
});
var groupMemberUrl = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups\/[a-z0-9.A-Z]{2,}\/members/;
var redirectPage = "friends.html";
$(function() {

  var auth = new Auth();
  var popup = new PopUp();
  // Check Auth
  popup.showCheckPopup();
  auth.checkAuthStatus();
  // auth.deleteStorage();
  // Initialization
  popup.init();
  popup.getTab()
  .then(tab => popup.setStatus(tab))
  .catch(e => {
    console.log(e);
  });

  // Fetching saved email id
  chrome.storage.local.get("emailID", function(items) {
    console.log(items);
    $(".loggedInAs").text(items.emailID);
  });

  // Logout function
  $("#logout").click(function() {
    auth.deleteStorage();
    window.close();
  });

  // Retrive previously added form data.
  popup.retrieveFormData();
  // Action if Stop Request Triggered
  $("#stopScript").click(function(){
    popup.getTab()
    .then(tab => popup.enableRun(tab))
    .then(bool => {
      console.log(bool);
    }).catch (e => {
      console.log(e);
    });
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      var payloads = {
        action: "stopScript",
        payload: {
          tabID: tabs[0].id
        }
      };
      popup.sendRequest(payloads);
    });
  });

  $("form").submit(function(e) {
    e.preventDefault();
    if (!popup.validation()) return;
    const data = $(this).serializeArray();
    const serializedData = popup.serializeFormData(data);
    // console.log(serializedData);
    const payload = {
      action: "sendFrndReq",
      payload: serializedData
    };
    // popup.disableRun();
    popup.getTab()
    .then(tab => popup.disableRun(tab))
    .then(bool => {
      console.log(bool);
    }).catch (e => {
      console.log(e);
    });
    popup.saveFormData(serializedData);
    popup.sendRequest(payload);
  });

});

/** START -- Popup related class */
class PopUp extends Communication {
  constructor() {
    super();
    this.init = this.init.bind(this);
    this.validation = this.validation.bind(this);
  }

  showCheckPopup() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      const currentUrl = tabs[0].url;
      if(groupMemberUrl.test(currentUrl)) {
        console.log('True');
      } else {
        // console.log('False');
        window.location.href = "./" + redirectPage;
      }

    });
  }

  init() {
    // port.postMessage({action: "isRunningGroupMember"});
    // chrome.runtime.onMessage.addlistener(function(request, sender, sendResponse) {
    //   console.log(request);
    // });
    // Initialize request limit
    $(".reqType").click(function() {
      if ($("#reqType_l").is(":checked")) {
        $("#numberOfReq").removeAttr("disabled");
        $(".noOfReqBlock").slideDown();
      } else {
        $("#numberOfReq").attr("disabled", "disabled");
        $(".noOfReqBlock").slideUp();
      }
    });

    $("#numberOfReq").blur(function() {
      if ($.trim($(this).val()) == "") {
        $(".nqMsg").css("display", "block");
      } else {
        $(".nqMsg").css("display", "none");
      }
    });

    $(".specificType").click(function() {
      if ($("#specific_y").is(":checked")) {
        $("#specificIndex").removeAttr("disabled");
        $(".memberIndex").slideDown();
      } else {
        $("#specificIndex").attr("disabled", "disabled");
        $(".memberIndex").slideUp();
        $(".siMsg").css("display", "none");
      }
    });

    $("#specificIndex").blur(function() {
      if ($.trim($(this).val()) == "") {
        $(".siMsg").css("display", "block");
      } else {
        $(".siMsg").css("display", "none");
      }
    });

  }

  validation() {
    // console.log("In Validation")
    var $isInfinite, $NREQ, $KW;
    var bool = true;
    $isInfinite = $("#reqType_i");
    $NREQ = $("#numberOfReq");
    $KW = $("#tagInput");
    if (!$isInfinite.is(":checked")) {
      if ($.trim($NREQ.val()) == "") {
        $(".nqMsg").css("display", "block");
        bool = false;
      } else {
        $(".nqMsg").css("display", "none");
        bool = true;
      }
    }
    return bool;
  }

  retrieveFormData() {
    chrome.storage.sync.get("formData", function(items) {
      if (items.formData) {
        $("#loadFormData").show();
        $(".interval option[value=" + 5000 + "]").attr(
          "selected",
          "selected"
        );
        if (items.formData.reqType == "1") {
          $("#reqType_i").removeAttr("checked");
          $("#reqType_l").attr("checked", "checked");
          $(".numberOfReq").val(items.formData.numberOfReq);
        } else {
          $("#reqType_l").removeAttr("checked");
          $("#reqType_i").attr("checked", "checked");
          $(".noOfReqBlock").css("display", "none");
        }

        if (items.formData.specific == "1") {
          $("#specific_n").removeAttr("checked");
          $("#specific_y").attr("checked", "checked");
          $(".memberIndex").css("display", "block");
          $("#specificIndex").val(items.formData.specificIndex);
        } else {
          $("#specific_y").removeAttr("checked");
          $("#specific_n").attr("checked", "checked");
          $(".memberIndex").css("display", "none");
          $("#specificIndex").attr('disabled','disabled');
        }

        if (items.formData.keywords) {
          $("#tagInput").val();
          $("#tagInput").tagsinput("add", items.formData.keywords.join());
        }
      } else {
        $("#loadFormData").hide();
      }
    });
  }

  saveFormData(data) {
    console.log(data);
    chrome.storage.sync.set({ formData: { ...data } }, function() {
      console.log("Saved");
    });
  }

  serializeFormData(data) {
    const formData = {};
    // Pushing this form data into a single object
    $.each(data, function(index, val) {
      if (val.name !== "keywords") {
        formData[val.name] = val.value;
      } else {
        if(val.value) {
          var keywords = val.value;
          formData[val.name] = keywords.split(",");
        } else {
          formData[val.name] = [];
        }
      }
    });
    return formData;
  }

  disableRun(tab) {
    return new Promise((resolve, reject) => {
      try {
        var arr = {
          tabID: tab.id,
          status: 'disable'
        };
        chrome.storage.local.get({gm: []}, function(data) {
          if(data.gm.length) {
            var group = data.gm;
            var index = data.gm.findIndex(el => {
              return el.tabID == tab.id;
            });
            if (index < 0) {
              group.push(arr);
            } else {
              group[index] = arr;
            }
            chrome.storage.local.set({gm: group}, function() {
              $("#sendRQBtn").css('display', 'none');
              $("#stopScript").css('display','block');
              resolve(true);
            });
          } else {
            chrome.storage.local.set({gm: [arr]}, function() {
              $("#sendRQBtn").css('display', 'none');
              $("#stopScript").css('display','block');
              resolve(true);
            });
          }
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_DISABLE_RUN', msg: e.message});
      }
    });

  }

  enableRun(tab) {
    return new Promise((resolve, reject) => {
      try {
        console.log("Stop pressed",tab.id);
        chrome.storage.local.get({gm: []}, function(data) {
          // var newGroup = data.group.find(el => {
          //   return el.tabID == tab.id;
          // });
          var newGroupMember = [];
          for(var i=0;i<data.gm.length;i++){
            // console.log("TID", data.gm[i].tabID);
            if (data.gm[i].tabID !== tab.id) {
              newGroupMember.push(data.gm[i]);
            }
          }
          chrome.storage.local.set({gm: newGroupMember}, function() {
            $("#sendRQBtn").css('display','block');
            $("#stopScript").css('display','none');
            resolve(true);
          });
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_ENABLE_RUN', msg: e.message});
      }
    });
  }

  setStatus(tab) {
    chrome.storage.local.get({gm: []}, function(data) {
      console.log(data);
      var status = false;
      // console.log(tab.id);
      for(var i=0;i<data.gm.length;i++){
        if (data.gm[i].tabID == tab.id) {
         status = true;
        }
      }
      if (status) {
        $("#sendRQBtn").css('display','none');
        $("#stopScript").css('display','block');
      } else {
        $("#sendRQBtn").css('display','block');
        $("#stopScript").css('display','none');
      }
    });
  }

  getTab() {
    return new Promise((resolve, reject) => {
      try {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
          resolve(tabs[0]);
        });
      } catch (e) {
        reject({errorType: 'CATCH_BLOCK_GET_TAB', msg: e.message})
      }
    })
  }
}
/** END -- Popup related class */

