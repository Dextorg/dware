var port = chrome.extension.connect({
  name: "Friends-Background"
});
/** START -- Check Authentication Class */
class Auth {
  constructor() {
    this.checkAuthStatus = this.checkAuthStatus.bind(this);
    this.tokenVerify = this.tokenVerify.bind(this);
  }

  checkAuthStatus() {
    chrome.storage.local.get("accessToken", this.tokenVerify);
  }

  tokenVerify(tokenData) {
    if (tokenData.accessToken) {
      fetch("https://portal.dwarelab.com/ext/users/checkStatus/Friend%20Maker%20Basic", {
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ userToken: tokenData.accessToken }) // body data type must match "Content-Type" header
      })
        .then(response => response.json())
        .then(res => {
          console.log(res);
          if (res.http_code === 403) {
            this.deleteStorage();
            this.redirectToLogin();
          }
        })
        .catch(err => {
          console.log("In Catch block");
          // this.deleteStorage();
          // this.redirectToLogin();
          // console.log(err.message);
        });
    } else {
      console.log("No Accesstoken found");
      this.redirectToLogin();
    }
  }

  redirectToLogin() {
    window.location.href = "auth/login.html";
  }

  deleteStorage() {
    chrome.storage.local.clear();
  }
}
/** END -- Check Authentication Class */

/** START -- Communication to background or content js */
class Communication {
  constructor() {
    this.sendRequest = this.sendRequest.bind(this);
    this.stopScriptRequest = this.stopScriptRequest.bind(this);
  }

  sendRequest(data) {
    try {
      port.postMessage(data);
    } catch (e) {
      console.log(e.message);
      alert("Runtime error! Please refresh the page.");
    }
  }

  stopScriptRequest(payloads) {
    console.log("Stop script request triggered");
    // Sending stop script request to content.js
    port.postMessage(payloads);
  }
}
/** END -- Communication to background or content js */
