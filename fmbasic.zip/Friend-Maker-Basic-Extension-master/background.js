// var groupMember = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups\/[a-z0-9]{2,}\/members/;

var groupMember = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups\/[a-z0-9A-Z]{2,}\/members/;
var friends = /^(http|https):\/\/(www.)*(facebook)(\.com)\/[a-z0-9.A-Z]{2,}\/friends/;
var facebook = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups/;
var regexURLs = [{
    regex: /^(http|https):\/\/(www.)*(facebook)(\.com)\/[a-z0-9.A-Z]{2,}\/friends/,
    popup: "friends.html"
}, {
    regex: /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups/,
    popup: "popup.html"
}, {
    regex: /^(http|https):\/\/(www.)*(facebook)(\.com)\/friends\/requests/,
    popup: "suggestion.html"
}, {
    regex: /^(http|https):\/\/(www.)*(facebook)(\.com)/,
    popup: "temp_del_pending.html"
}];
var apiURL = "https://portal.dwarelab.com";
var dashboard = "popup.html";
var disabled = "nopopup.html";
// var friendsHtml = "friends.html";
var login = "login.html";
var activePopup = disabled;
// START -- Chrome listeners

chrome.extension.onConnect.addListener(function (port) {
    // console.log("Connected .....");
    port.onMessage.addListener(function (msg) {
        // console.log(msg);
        switch (msg.action) {
            case "delPending":
                openPendingRequestPage(msg.payload.interval);
                break;
            default:
                sendToContentScript(msg);
                break;
        }
    });
});

chrome.runtime.onConnect.addListener(function (port) {
    // // console.log("Content Script Connected from port", port.name);
    port.onMessage.addListener(function (param) {
        // console.log(param);
        switch (param.action) {
            case 'notify':
                if (param.badge) {
                    console.log("Badge set", param);
                    chrome.browserAction.setBadgeText({text: param.badge.text, tabId: param.badge.tabID});
                }
                if (param.notification) {
                    var notifOptions = {
                        type: "basic",
                        iconUrl: "assets/friend_connector.png",
                        ...param.notification
                    };
                    chrome.notifications.create(param.notifID.toString(), notifOptions);
                }
                break;
            case 'resetBadge':
                chrome.browserAction.setBadgeText({text: '', tabId: param.tabID});
                break;
            case 'enableRun':
                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    enableRunFL(tabs[0]).catch(e => {
                        // // console.log(e.message);
                    });
                });
                var win = chrome.extension.getViews({type: "friends"});
                win[0].close();
                // // console.log('Enable Run Triggered');
                break;
            case 'enableRunGM':
                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    enableRunGM(tabs[0]).catch(e => {
                        // // console.log(e.message);
                    });
                });
                var win = chrome.extension.getViews({type: "popup"});
                win[0].close();
                // // console.log('Enable Run Triggered');
                break;
            case 'enableRunSF':
                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    enableRunSF(tabs[0]).catch(e => {
                        // // console.log(e.message);
                    });
                });
                var win = chrome.extension.getViews({type: "suggestion"});
                win[0].close();
                // // console.log('Enable Run Triggered');
                break;
            case 'closeTab':
                chrome.tabs.remove(param.tab.id, function () {
                });
                break;
            case 'unFriendAll':
                // chrome.tabs.sendMessage(
                //   tab.id,
                //   { action: "unfriendAll", tab: param.tab },
                //   function(res) {
                //     console.log(res);
                //   }
                // );
                openUnfriendPage(param.path);
                break;
        }
    });
});

chrome.tabs.onActivated.addListener(function (activeInfo) {
    chrome.tabs.get(activeInfo.tabId, function (tab) {
        popupSet(tab)
            .then(function (res) {
                chrome.browserAction.setPopup({popup: res.popup}, function (e) {
                    // console.log("popup set on activated");
                });
            }).catch(function (e) {
            // console.log("On Activated catch method", e);
            chrome.browserAction.setPopup({popup: e.popup}, function (e) {
                // console.log("popup set on activated catch");
            });
            // chrome.browserAction.setPopup(e);
        }).finally(function () {
            scriptInjection(tab.status, tab.url, tab.id);
        });
    });
});

chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    console.log("Updated");
    enableRunGM(tab).then(bool => {
        // console.log(bool);
    });
    enableRunFL(tab).then(bool => {
        // console.log(bool);
    });

    enableRunSF(tab).then(bool => {
        // console.log(bool);
    });

    chrome.browserAction.setBadgeText({text: '', tabId: tabId});

    if (change.status == "complete") {
        popupSet(tab, change.url)
            .then(function (res) {
                // console.log(res);
                chrome.browserAction.setPopup({popup: res.popup}, function (e) {
                    // console.log("popup set on updated");
                });
            })
            .catch(function (e) {
                // console.log("On Updated catch method", e.error);
                chrome.browserAction.setPopup({popup: e.popup}, function (e) {
                    // console.log("popup set on updated catch");
                });
            }).finally(function () {
            scriptInjection(tab.status, tab.url, tab.id);
        });

        // Setting up unfriend all button
        console.log("From Update Tab", tab);
        // console.log(regexURLs[0].regex.test(tab.url));
        if (regexURLs[0].regex.test(tab.url)) {
            chrome.storage.local.get("accessToken", function (token) {
                if (token.accessToken.length) {
                    chrome.tabs.sendMessage(
                        tab.id,
                        {action: "setUnfriendButton", tab: tab},
                        function (res) {
                            console.log(res);
                        }
                    );
                }
            });
        }
    }
});
// END -- Chrome Listers

// Functions

function popupSet(tab, changeUrl = false) {
    return new Promise((resolve, reject) => {
        try {
            const url = changeUrl ? changeUrl : tab.url;
            if (tab.active && tab.status === "complete") {
                const activePopup = regexURLs.filter(obj => {
                    return obj.regex.test(url) == true;
                });
                // console.log(activePopup);
                if (activePopup.length) {
                    tab.popup = activePopup[0].popup;
                } else {
                    tab.popup = disabled;
                }
                resolve(tab);
            } else {
                // console.log("Error! Tab Active",tab.active,"Tab Status",tab.status);
                tab.popup = disabled;
                resolve(tab);
            }
        } catch (e) {
            // console.log("CATCH BLOCK", e.message);
            tab.popup = disabled;
            tab.error = e.message;
            reject(tab);
        }
    });
}

function scriptInjection(status, url, tabID) {
    if (status === "complete") {
        if (facebook.test(url) || friends.test(url)) {
            injectContentScript("jquery.min.js", tabID)
                .then(res => injectContentScript("jquery.toast.min.js", res.tabID))
                .then(res => injectContentScript("content.inj.js", res.tabID))
                .catch(err => {
                    // console.log("Error--", err.message);
                });
        }
    }
}

function getPopup(url, tabID = null) {
    if ((facebook.test(url) || friends.test(url)) && tabID) {
        chrome.browserAction.getPopup({
            tabID: tabID,
            popup: activePopup
        });
    } else {
        chrome.browserAction.getPopup({popup: disabled});
    }
}

function init(tabID) {
    // console.log(tabID);
    // console.log("Actual Popup Already Set");
}

function injectContentScript(fileName, tabID) {
    return new Promise((resolve, reject) => {
        try {
            chrome.tabs.executeScript(tabID, {file: fileName}, function (e) {
                // console.log(e);
                // console.log(fileName, "Injected");
                resolve({fileName: fileName, tabID: tabID});
            });
        } catch (e) {
            reject(e.message);
        }
    });
}

function checkAuthToken(tab) {
    return new Promise((resolve, reject) => {
        try {
            chrome.storage.local.get("accessToken", function (data) {
                // // console.log(tab);
                var testURL = regexURLs.filter(url => {
                    return url.test(tab.url);
                });
                if (testURL.length) {
                    if (data.accessToken) {
                        tab.accessToken = data.accessToken;
                        resolve(tab);
                    } else {
                        tab.accessToken = null;
                        tab.popup = login;
                        reject(tab);
                    }
                } else {
                    tab.popup = disabled;
                    reject(tab);
                }
            });
        } catch (e) {
            tab.accessToken = null;
            tab.error = e.message;
            tab.popup = disabled;
            reject(tab);
        }
    });
}

function enableRunGM(tab) {
    return new Promise((resolve, reject) => {
        try {
            // console.log("On Updated pressed",tab.id);
            chrome.storage.local.get({gm: []}, function (data) {
                // var newGroup = data.group.find(el => {
                //   return el.tabID == tab.id;
                // });
                var newGroupMember = [];
                for (var i = 0; i < data.gm.length; i++) {
                    // // console.log("TID", data.gm[i].tabID);
                    if (data.gm[i].tabID !== tab.id) {
                        newGroupMember.push(data.gm[i]);
                    }
                }
                chrome.storage.local.set({gm: newGroupMember}, function () {
                    resolve(true);
                });
            });
        } catch (e) {
            reject({errorType: 'CATCH_BLOCK_ENABLE_RUN', msg: e.message});
        }
    });
}

function enableRunSF(tab) {
    return new Promise((resolve, reject) => {
        try {
            // console.log("On Updated pressed",tab.id);
            chrome.storage.local.get({sf: []}, function (data) {
                // var newGroup = data.group.find(el => {
                //   return el.tabID == tab.id;
                // });
                var newGroupMember = [];
                for (var i = 0; i < data.sf.length; i++) {
                    // // console.log("TID", data.sf[i].tabID);
                    if (data.sf[i].tabID !== tab.id) {
                        newGroupMember.push(data.sf[i]);
                    }
                }
                chrome.storage.local.set({sf: newGroupMember}, function () {
                    resolve(true);
                });
            });
        } catch (e) {
            reject({errorType: 'CATCH_BLOCK_ENABLE_RUN', msg: e.message});
        }
    });
}

function enableRunFL(tab) {
    return new Promise((resolve, reject) => {
        try {
            // console.log("On Updated pressed",tab.id);
            chrome.storage.local.get({fl: []}, function (data) {
                // var newGroup = data.group.find(el => {
                //   return el.tabID == tab.id;
                // });
                var newGroupMember = [];
                for (var i = 0; i < data.fl.length; i++) {
                    // // console.log("TID", data.fl[i].tabID);
                    if (data.fl[i].tabID !== tab.id) {
                        newGroupMember.push(data.fl[i]);
                    }
                }
                chrome.storage.local.set({fl: newGroupMember}, function () {
                    resolve(true);
                });
            });
        } catch (e) {
            reject({errorType: 'CATCH_BLOCK_ENABLE_RUN', msg: e.message});
        }
    });
}

function sendToContentScript(msg) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        msg.tabID = tabs[0].id;
        chrome.tabs.sendMessage(tabs[0].id, msg, function (data) {
            if (chrome.runtime.lastError) {
                // console.log(chrome.runtime.lastError);
            } else {
                // console.log(data);
            }
        });
    });
}

// Delete pending Friend Request Functions
const openPendingRequestPage = (interval) => {
    var newURL = "https://m.facebook.com/friends/center/requests/outgoing/";
    openUrl(newURL)
        .then(tab => checkTabStatus(tab))
        .then(tab => {
            console.log("Send Message Tab", tab);
            chrome.tabs.sendMessage(
                tab.id,
                {action: "delPending", tabID: tab.id, tab: tab, interval: interval},
                function (res) {
                    console.log(res);
                }
            );
        })
        .catch(e => {
            console.log("ERROR", e);
        });
};

const openUnfriendPage = (path) => {
    openUrl("https://m.facebook.com" + path)
        .then(tab => checkTabStatus(tab))
        .then(tab => {
            console.log("Send Message Tab", tab);
            chrome.tabs.sendMessage(
                tab.id,
                {action: "unfriendAll", tab: tab},
                function (res) {
                    console.log(res);
                }
            );
        })
        .catch(e => {
            console.log("ERROR", e);
        });
};

const openUrl = url => {
    return new Promise((resolve, reject) => {
        try {
            chrome.tabs.create({url: url}, function (tab) {
                resolve(tab);
            });
        } catch (e) {
            reject(e.message);
        }
    });
};

const checkTabStatus = tab => {
    return new Promise((resolve, reject) => {
        try {
            chrome.tabs.onUpdated.addListener(function delPendinglistener(tabId, info) {
                if (info.status === "complete" && tabId === tab.id) {
                    console.log("Tab Info", info);
                    chrome.tabs.onUpdated.removeListener(delPendinglistener);
                    tab.status = info.status;
                    resolve(tab);
                }
            });
        } catch (e) {
            reject(e.message);
        }
    });
};
// function setPopup(url) {
//   if (facebook.test(url)) {
//     chrome.browserAction.setPopup({ popup: dashboard });
//   } else {
//     chrome.browserAction.setPopup({ popup: disabled });
//   }
// }
