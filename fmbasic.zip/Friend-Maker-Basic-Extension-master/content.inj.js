
// Global Variables for Content Script

var port;
var timeout;
let members = [];
var payload, membersRow, timeoutInterval, groupScriptStatus, friendReqStatus, suggestedReqStatus;
var groupReqSent = 0;
var frndReqSent = 0;
var suggestedSent = 0;
var taostID;

$(document).ready(function () {
    port = chrome.runtime.connect({name: "contentScriptConnect"});
    // Adding unfriend all button in facebook
    setUnfriendBtn();
    // unfriendAllM();

    // Unfriend btn click event
    $("#unfrnd").click(function () {
        console.log("Unfriend Click Event Triggered");
        toast(
            "Task Started",
            "Please leave your mouse don't click or do anything in this page, If you want to stop anywhere just refresh the page",
            0,
            true
        );
        unfriendAll();
        // port.postMessage({action: "unFriendAll", path: window.location.pathname});
    });
    // END of Adding unfriend all button in facebook
    groupScriptStatus = 0;
    friendReqStatus = 0;
    suggestedReqStatus = 0;
    // friendList = new FrinedOfFriendList();
    chrome.runtime.onMessage.addListener(cbListener);
});

// On message callback
const cbListener = (param, sender, sendResponse) => {
    // console.log(param);
    switch (param.action) {
        case "sendFrndReq":
            taostID = toast(
                "Task Started & Running",
                "Your script has been started. Do not refresh the page.",
                3,
                true
            )
            param.payload.tabID = param.tabID;
            groupScriptStatus = 1;
            const initPosition = (parseInt(param.payload.specific)) ? (parseInt(param.payload.specificIndex) - 1) : 0;
            sendGroupMemberRequest(param.payload, initPosition);
            break;
        case "stopScript":
            groupScriptStatus = 0;
            toast(
                "Task Stopped",
                "Running task has been stopped/ended",
                0
            );
            stopGroupRequest();
            break;
        case "sendFrndReqOfFriend":
            taostID = toast(
                "Task Started & Running",
                "Your script has been started. Do not refresh the page.",
                3,
                true
            )
            param.payload.tabID = param.tabID;
            friendReqStatus = 1;
            sendFriendListRequest(param.payload);
            break;
        case "stopFrndReqOfFriend":
            friendReqStatus = 0;
            stopFriendsFriendReq();
            toast(
                "Task Stopped",
                "Running task has been stopped/ended",
                0
            );
            break;
        case "delPending":
            const delPending = new DeletePendingFriends();
            delPending.deletePending(0, param.tab, param.interval);
            break;
        case 'setUnfriendButton':
            console.log("Triggered to set unfriend button");
            setTimeout(function () {
                setUnfriendBtn();
            }, 2000);
            break;
        case 'unfriendAll':
            console.log("Unfriend All Triggered from background");
            break;
        case 'sendSuggestionReq':
            // console.log('Suggestion Friend got', param);
            taostID = toast(
                "Task Started & Running",
                "Your script has been started. Do not refresh the page.",
                3,
                true
            );
            suggestedReqStatus = 1;
            param.payload.tabID = param.tabID;
            sendSuggestedRequests(param.payload);
            break;

        case 'stopSuggestionScript':
            suggestedReqStatus = 0;
            console.log("Got to stop suggested script");
            // param.payload.tabID = param.tabID;
            stopSuggestedRequests();
            break;
    }
    return true;
};

/* DELETE PENDING FRIEND CLASS */
class DeletePendingFriends {

    inverval;
    timeout;

    constructor() {
    }

    deletePending(counter = 0, tabs = null, interval) {
        var t = this;
        clearTimeout(t.timeout);
        // chrome.tabs.remove(tabs.id, function(){});
        const cancelBtn = $("._56bt");
        const btnLength = cancelBtn.length;
        t.cancelPending(cancelBtn, btnLength, counter).then(res => {
            var rand = Math.floor(Math.random() * (6 - 1 + 1) + 1);
            t.timeout = setTimeout(function () {
                const resCount = res.count + 1;
                t.deletePending(resCount, tabs, interval);
            }, interval);
        }).catch(e => {
            // console.log(e);
            if (e.closeWindow) {
                port.postMessage({action: "closeTab", tab: tabs});
            }
        });
    }

    cancelPending(el, btnLength, counter = 0) {
        return new Promise((resolve, reject) => {
            try {
                var t = this;
                // console.log(el);
                console.log("Counter = ", counter, "Btn Length", btnLength);
                if (counter == btnLength) {
                    reject({closeWindow: true});
                } else {
                    console.log(counter);
                    t.scrollToPos($(el[counter]).parent());
                    el[counter].click();
                    // $(el[counter]).css("background","blue");
                    t.toast("Request Cancelled", `${counter + 1} friend request(s) has been cancelled`);
                    resolve({el: el, btnLength: btnLength, count: counter});
                }
            } catch (e) {
                reject({error: e.message, closeWindow: false});
            }
        });
    }


    toast(heading, body, type = 1) {
        var toastType = ["error", "success", "info", "warning"];
        const options = {
            heading: heading,
            text: body,
            showHideTransition: "slide",
            icon: toastType[type],
            position: "bottom-right"
        };
        if (type == 3) {
            options.hideAfter = false;
        }
        return $.toast(options);
    }

    scrollToPos(el) {
        $("html,body").animate({
            scrollTop: $(el).offset().top - 15
        }, "slow");
    }


}

/* END OF DELETE PENDING FRIEND CLASS */


/* --------- FUNCTIONS FOR SENDING FRIEND REQUEST TO GROUP MEMBERS --------- */


const sendGroupMemberRequest = (payload, initPos = 0) => {
    payload = payload;
    console.log("-------------");
    membersRow = $(".clearfix").find("[data-name='GroupProfileGridItem']");
    if (membersRow.length === 0)
        membersRow = $(".clearfix").find("[class='clearfix _60rh _gse']");
    const rowLength = membersRow.length;
    console.log("Row Length", rowLength);
    console.log(payload);

    const findRelevantPeople = (callback) => {
        const users = [];
        for (var i = initPos; i < rowLength; i++) {
            // Setting Badge Count for Member walkthrough
            const badgeEl = $(membersRow[i]).find("._60ri").find('.badge');
            const badge = '<sup class="badge">' + (i + 1) + '</sup>';
            if (badgeEl.length) {
                badgeEl[0].innerText = (i + 1);
            } else {
                $(membersRow[i]).find("._60ri").append(badge);
            }
            // END -- Setting Badge Count for Member walkthrough
            const el = membersRow[i];
            const frndBtn = $(el).find(".FriendRequestAdd");
            const anchor = $(el).find("a");
            const name = anchor[1].innerText;
            const profile = anchor[1].href;
            var keyDiv = $(el).find("._6a").find("._60rj");
            const isHidden = $(frndBtn).hasClass("hidden_elem");
            const user = {
                name: name,
                profileUrl: profile,
                designation: keyDiv[(keyDiv.length - 1)].innerText,
                uiPos: i
            };
            if (frndBtn.length && !isHidden) {
                if (payload.keywords.length) {
                    const keywords = payload.keywords;
                    const validate = keywords.find(arrEl => {
                        var rSearchTerm = new RegExp('\\b' + arrEl.toLowerCase() + '\\b', 'i');
                        var subEl = user.designation.toLowerCase();
                        return subEl.match(rSearchTerm);
                    });
                    if (validate !== undefined) users.push(user);
                } else {
                    users.push(user);
                }
            }
        }
        if (users.length) {
            const pos = (users[0].uiPos) ? users[0].uiPos - 1 : users[0].uiPos;
            scrollToPos(membersRow[pos]);
            $(membersRow[users[0].uiPos]).addClass("loading_w");
        }
        callback(users);
    };

    if (parseInt(payload.specific) && parseInt(payload.specificIndex) > rowLength) {
        console.log("In Specifc index if block");
        toast(`Only ${rowLength} members loaded`, `The member in ${payload.specificIndex} position not loaded yet. Please scroll manually to load and then start`, 0, 10000);
        stopGroupRequest();
    } else {
        console.log("In else block");
        // if(initPos > 0) scrollToPos(membersRow[(initPos-1)]);
        const childClass = $(".fbProfileBrowserListContainer").find(".fbProfileBrowserList");
        const relevantLength = (childClass.length) ? (childClass.length) - 1 : 0;
        const isEndOfEl = $(childClass[relevantLength]).hasClass('fbProfileBrowserNoMoreItems');
        console.log($(childClass[relevantLength]).hasClass('fbProfileBrowserNoMoreItems'));

        findRelevantPeople(function (users) {
            console.log("Started");
            console.log(users.length, "Requests to be sent");
            var i = 0;
            const newLength = rowLength + 1;
            if (users.length) {
                // Scroll and Send Request
                const rand = (payload.interval / 1000) + (Math.floor(Math.random() * (3 - 1 + 1) + 1));
                console.log("Random interval in seconds", rand);
                timeoutInterval = setInterval(function () {
                    $(membersRow[users[i].uiPos]).removeClass("loading_w").addClass("working");
                    console.log("Interval ID", timeoutInterval);
                    const frndBtn = $(membersRow[users[i].uiPos]).find(".FriendRequestAdd");
                    // const randTimeout = Math.floor((Math.random() * (2 - 1 + 1) + 1)*1000);

                    // setTimeout(function() {
                    simulateClick(frndBtn);
                    groupReqSent++;
                    const notification = {
                        title: groupReqSent + " Group Member Requests Sent",
                        message: "Request sent"
                    };
                    notifyUser(payload, notification, groupReqSent);
                    console.log("Request Sent, Looking for any popup opened or not");
                    layerCancelOrConfirm();
                    if (payload.reqType) {
                        if (groupReqSent === 30) stopGroupRequest();
                    }
                    // console.log("Waited for",randTimeout+"ms");
                    // clearTimeout(clickTimeout);
                    // },randTimeout);
                    // console.log("Clicked");
                    showMore();
                    i++;
                    // const scrollPosition = (users[i].uiPos)?(users[i].uiPos)-1:users[i].uiPos;
                    const scrollPosition = ((i + 1) > users.length) ? (users[users.length - 1].uiPos) - 1 : (users[i].uiPos) - 1;
                    scrollToPos(membersRow[scrollPosition]);
                    if (users.length == i || i > users.length) {
                        console.log("Temp i value is ", i);
                        console.log("User length is", users.length);
                        console.log("All Done. Starting Afresh");
                        clearInterval(timeoutInterval);
                        showMore();
                        sendGroupMemberRequest(payload, newLength);
                    } else {
                        $(membersRow[users[i].uiPos]).addClass("loading_w");
                    }
                }, rand * 1000);
            } else {
                if (!isEndOfEl && groupScriptStatus) {
                    console.log("Users Not Found. Initiating restart");
                    scrollToPos(membersRow[(rowLength - 5)]);
                    showMore();
                    var t = setTimeout(function () {
                        console.log("Recalled Function");
                        showMore();
                        clearTimeout(t);
                        sendGroupMemberRequest(payload, newLength);
                    }, 1000);
                } else {
                    stopGroupRequest();
                    console.log("End Of Group Search");
                }
            }
        });
    }
}

const showMore = () => {
    var seeMoreEl = $(".uiMorePagerPrimary");
    var len = seeMoreEl.length;
    //console.log("See More Button Length",seeMoreEl);
    if (len) {
        if (seeMoreEl[len - 1].innerText.toLowerCase() == "see more") {
            seeMoreEl[len - 1].click();
        }
    }
};

const stopGroupRequest = () => {
    var mrg = $(".clearfix").find("[data-name='GroupProfileGridItem']");
    var mrg2 = $(".clearfix").find("[class='clearfix _60rh _gse']");
    groupScriptStatus = 0;
    setTimeout(function () {
        $(mrg).removeClass("loading_w");
        $(mrg2).removeClass("loading_w");
    }, 200);
    console.log("Stop interval ID", timeoutInterval);
    window.clearInterval(timeoutInterval);
    port.postMessage({action: "enableRunGM"});
    taostID.reset();
};

/* --------- END OF GROUP MEMBERS FUNCTIONS --------- */

/* --------- FUNCTIONS FOR FRIEND REQUEST TO FRIEND LIST OF A FRIEND --------- */

const sendFriendListRequest = (payload, initPos = 0) => {
    payload = payload;
    console.log(payload);
    membersRow = $("#pagelet_timeline_medley_friends").find("._30f").find("[data-testid='friend_list_item']");
    const rowLength = membersRow.length;
    const loadedEl = $("#pagelet_timeline_medley_friends").find("._359");
    console.log(rowLength);
    if (parseInt(payload.specific) && parseInt(payload.specificIndex) > rowLength) {
        toast(`Only ${rowLength} friends loaded`, `The member in ${payload.specificIndex} position not loaded yet. Please scroll manually to load and then start`, 0, 10000);
        stopFriendsFriendReq();
    } else {
        // if(initPos > 0) scrollToPos(membersRow[(initPos-1)]);
        // Function to find people from the loaded in UI list with matched keywords & Add Friend button active
        const findRelevantPeople = (callback) => {
            console.log("In Find Relevant People Function");
            const users = [];
            for (var i = initPos; i < rowLength; i++) {
                const el = membersRow[i];
                // Setting Badge Count for Member walkthrough
                const badge = '<sup class="badge">' + (i + 1) + '</sup>';
                const badgeEl = $(el).find(".fcb").find('.badge');
                if (badgeEl.length) {
                    badgeEl[0].innerText = (i + 1);
                } else {
                    $(el).find(".fcb").append(badge);
                }
                // END -- Setting Badge Count for Member walkthrough

                const frndBtn = $(el).find(".FriendRequestAdd");
                const anchor = $(el).find("a");
                const name = anchor[1].innerText;
                const profile = anchor[1].href;
                const profileContent = $(el).find(".uiProfileBlockContent"); // Getting html for uiProfileBlockContent div
                const uiList = $(profileContent).find(".uiList"); // Finding uiList within uiProfileBlockContent div. designation = uiList[0].innerText;
                const isHidden = $(frndBtn).hasClass("hidden_elem");
                const user = {
                    name: name,
                    profileUrl: profile,
                    uiPos: i
                };
                if (frndBtn.length && !isHidden) {
                    if (payload.keywords.length) {
                        if (uiList.length) { // Add condition in Mutual Friend condition in OR with uilist.length checking if require in future
                            user.designation = uiList[0].innerText;
                            const keywords = payload.keywords;
                            const validate = keywords.find(arrEl => {
                                var rSearchTerm = new RegExp('\\b' + arrEl.toLowerCase() + '\\b', 'i');
                                var subEl = user.designation.toLowerCase();
                                return subEl.match(rSearchTerm);
                            });
                            if (validate) users.push(user);
                        }
                    } else {
                        users.push(user);
                    }
                }
            }
            if (users.length) {
                const pos = (users[0].uiPos) ? users[0].uiPos - 2 : users[0].uiPos;
                scrollToPos(membersRow[pos]);
                console.log(users);
                $(membersRow[users[0].uiPos]).parent().addClass("loading_w");
            }
            // console.log(users);
            callback(users);
        };

        findRelevantPeople(function (users) {
            console.log("Started");
            var i = 0;
            const nextStartPos = rowLength + 1;
            if (users.length) {
                // Scroll and Send Request
                const rand = (payload.interval / 1000) + (Math.floor(Math.random() * (3 - 1 + 1) + 1));
                timeoutInterval = setInterval(function () {
                    $(membersRow[users[i].uiPos]).parent().removeClass("loading_w").addClass("working");
                    console.log("Interval ID", timeoutInterval);
                    console.log(users);
                    const scrollPosition = (users[i].uiPos) - 2;
                    scrollToPos(membersRow[scrollPosition]);
                    const frndBtn = $(membersRow[users[i].uiPos]).find(".FriendRequestAdd");
                    // const randTimeout = Math.floor((Math.random() * (2 - 1 + 1) + 1)*1000);
                    // console.log("Random Timeout",randTimeout);
                    // var clickTime = setTimeout(function() {
                    simulateClick(frndBtn);
                    frndReqSent++;
                    const notification = {
                        title: frndReqSent + " Friend Requests Sent",
                        message: "Request sent"
                    };
                    notifyUser(payload, notification, frndReqSent);
                    layerCancelOrConfirm();
                    /* --- Enable if number of request to be sent required ---- */
                    if (payload.reqType) {
                        if (frndReqSent === 30) {
                            // console.log("Limited Requests to send friend requests");
                            stopFriendsFriendReq();
                        }
                        ;
                    }
                    i++;
                    const scrollPos = ((i + 1) > users.length) ? (users[users.length - 1].uiPos) - 1 : (users[i].uiPos) - 1;
                    scrollToPos(membersRow[scrollPos]);
                    if (users.length == i || i > users.length) {
                        console.log("All Done. Starting Afresh");
                        console.log("Start from", nextStartPos);
                        // scrollToPos(membersRow[rowLength]);
                        clearInterval(timeoutInterval);
                        sendFriendListRequest(payload, nextStartPos);
                    } else {
                        $(membersRow[users[i].uiPos]).parent().addClass("loading_w");
                    }
                    // clearTimeout(clickTime);
                    // },randTimeout);

                }, rand * 1000);
            } else {
                console.log("Users Not Found. Calling the function recursively");
                scrollToPos(membersRow[(rowLength - 10)]);
                // showMore();
                if (friendReqStatus && loadedEl.length == 1) {
                    console.log("In Condition", friendReqStatus, loadedEl.length);
                    scrollToPos(membersRow[(rowLength - 5)]);
                    var t = setTimeout(function () {
                        clearTimeout(t);
                        sendFriendListRequest(payload, nextStartPos);
                    }, 1000);
                } else {
                    console.log("End of List");
                    stopFriendsFriendReq();
                }
            }

        });
    }
};

const stopFriendsFriendReq = () => {
    // var membersRow = $(".clearfix").find("[data-name='GroupProfileGridItem']");
    friendReqStatus = 0;
    const mr = $("#pagelet_timeline_medley_friends").find("._30f").find("[data-testid='friend_list_item']");
    setTimeout(function () {
        $(mr).parent().removeClass("loading_w");
    }, 200);
    console.log("Stop interval ID", timeoutInterval);
    window.clearInterval(timeoutInterval);
    port.postMessage({action: "enableRun"});
    taostID.reset();
};

/* --------- END OF FRIEND REQUEST TO FRIEND LIST OF A FRIEND FUNCTIONS --------- */

/* --------- FUNCTIONS FOR UNFRIEND ALL FRIENDS --------- */
const unfriendAll = (startFrom = 0, interval = 15000) => {
    $("#fcBodyWrapper").css("display", "block");
    let startPos = startFrom;
    clearTimeout(timeoutInterval);
    const membersRow = $("#pagelet_timeline_medley_friends").find("[data-testid='friend_list_item']");
    var btn = $(document).find('.friendButton');
    console.log("To be triggered and start from", startFrom);
    console.log("Triggered within", interval);
    btn[startPos].click();
    if (btn[startPos] == undefined) {
        unfriendAll(startPos);
    }
    setTimeout(function () {
        clearTimeout();
        const randInterval = randomIntFromInterval(4, 15);
        scrollToPos(membersRow[startPos]);
        var unfriendBtn = $(document).find('.FriendListUnfriend').find(".itemAnchor");
        unfriendBtn[0].click();
        console.log("Next Interval to start from", randInterval);
        startPos++;
        unfriendAll(startPos, randInterval);
    }, interval);
}

const setUnfriendBtn = () => {
    console.log("Got to set unfriend button");
    var unfrndBtnDiv = $("._69l").find("span");
    const anchBtns = $(unfrndBtnDiv).find("a");
    console.log($(anchBtns[0]).hasClass("friendButton"));
    if (anchBtns.length > 1 || !$(anchBtns[0]).hasClass("friendButton")) {
        var hasUnfrndBtn = $(unfrndBtnDiv[0]).find("#unfrnd");
        if (!hasUnfrndBtn.length) {
            //TODO Unfriend All Button
            /*const injectBtn = `<a role="button" class="_42ft _4jy0 _4-rs _4-rt _4jy4 _517h _51sy"
            style="background: url(https://s3.amazonaws.com/friendconnector.io/image/Group+75.png) no-repeat;
            background-size: 27px;
            background-position-x: 3px;
            background-position-y: 3px;
            padding-left: 32px;" href="#" id="unfrnd" onclick="unfriendAll()">Unfriend All</a>`;

            const wrapperDiv = `<div id="fcBodyWrapper" style="position: fixed; top: 0; bottom: 0; left: 0; right: 0;
            background: rgba(0,0,0,0.4); display: none; z-index: 99999;"></div>`;

            $(unfrndBtnDiv[0]).append(injectBtn);
            $('body').append(wrapperDiv);*/
        }
        // document.getElementById('unfrnd').addEventListener("click", function() {
        //   console.log("Unfriend Click Event Triggered from default");
        //   unfriendAll();
        //   // port.postMessage({action: "unFriendAll", path: window.location.pathname});
        // }, false);
    }
}
/* --------- END OF UNFRIEND ALL FRIENDS FUNCTIONS --------- */

/* ---------------- FUNCTIONS FOR SEND REQUESTS TO FB SUGGESTIONS ---------------  */
const sendSuggestedRequests = (payload, initPos = 0) => {
    console.log("Inside Suggested Friend");
    payload = payload;
    membersRow = $(".friendBrowserListUnit");
    const rowLength = membersRow.length;
    console.log("Row Length", rowLength);
    console.log(payload);


    const findRelevantPeople = (callback) => {
        const users = [];
        for (var i = initPos; i < rowLength; i++) {
            const el = membersRow[i];
            const frndBtn = $(el).find(".FriendRequestAdd");
            const isHidden = $(frndBtn).hasClass("hidden_elem");
            const titleUrlBlock = $(el).find(".friendBrowserNameTitle").find('a');
            const name = $(titleUrlBlock[0]).text();
            const profile = $(titleUrlBlock[0]).attr("href");
            const img = $(el).find(".fbProfileLargePortraitImgSmall").attr("src");
            const user = {
                name: name,
                profileUrl: profile,
                img: img,
                uiPos: i
            };
            if (frndBtn.length && !isHidden && user.name !== undefined) {
                if (payload.mutual) {
                    const mutualText = $(el).find(".friendBrowserMarginTopMini").find("table").find("a");
                    let txt = "";
                    console.log("Mutual Block", mutualText);
                    let noOfMutual = null;
                    switch (mutualText.length) {
                        case 1:
                            txt = mutualText[0].innerText;
                            noOfMutual = parseInt(txt.match(/\d+/g).map(Number));
                            // console.log("Number of Mutual Friends", noOfMutual);
                            break;
                        case 2:
                            noOfMutual = 1;
                            // console.log("Number of Mutual Friends", noOfMutual);
                            break;
                        case 3:
                            txt = mutualText[2].innerText;
                            noOfMutual = (parseInt(txt.match(/\d+/g).map(Number))) + 1;
                            // console.log("Number of Mutual Friends", noOfMutual);
                            break;
                        default:
                            noOfMutual = 0;
                            break;
                    }
                    if (noOfMutual !== null) {
                        if (payload.gtlt == 'gteq' && noOfMutual >= parseInt(payload.mutual)) {
                            console.log("Within the block gteq");
                            // $(membersRow[i]).addClass("loading_w");
                            users.push(user);
                        }

                        if (payload.gtlt == 'lteq' && noOfMutual <= parseInt(payload.mutual)) {
                            console.log("Within the block lteq");
                            // $(membersRow[i]).addClass("loading_w");
                            users.push(user);
                        }
                    }
                } else {
                    // $(membersRow[i]).addClass("loading_w");
                    users.push(user);
                }
            }
        }
        // console.log(users);
        if (users.length) {
            const pos = (users[0].uiPos) ? users[0].uiPos - 1 : users[0].uiPos;
            scrollToPos(membersRow[pos]);
            console.log(users);
            $(membersRow[users[0].uiPos]).addClass("loading_w");
        }
        callback(users);
    };

    findRelevantPeople(function (users) {
        console.log("Users Found", users);
        var i = 0;
        const newLength = rowLength + 1;
        if (users.length) {
            // Scroll and Send Request
            const rand = (payload.interval / 1000) + (Math.floor(Math.random() * (3 - 1 + 1) + 1));
            console.log("Random interval in seconds", rand);
            timeoutInterval = setInterval(function () {
                $(membersRow[users[i].uiPos]).removeClass("loading_w").addClass("working");
                console.log("Interval ID", timeoutInterval);
                const frndBtn = $(membersRow[users[i].uiPos]).find(".FriendRequestAdd");
                simulateClick(frndBtn);
                suggestedSent++;
                const notification = {
                    title: "Friend Request sent",
                    message: suggestedSent + " Suggested Friend Requests Sent"
                };
                notifyUser(payload, notification, suggestedSent);
                console.log("Request Sent, Looking for any popup opened or not");
                layerCancelOrConfirm();
                seeMore();
                if (payload.reqType) {
                    if (suggestedSent === 30) {
                        stopSuggestedRequests();
                    }
                    ;
                }
                i++;
                const scrollPosition = ((i + 1) > users.length) ? (users[users.length - 1].uiPos) - 1 : (users[i].uiPos) - 1;
                console.log("Scroll pos", scrollPosition);
                scrollToPos(membersRow[scrollPosition]);
                if (users.length == i || i > users.length) {
                    console.log("Temp i value is ", i);
                    console.log("User length is", users.length);
                    console.log("All Done. Starting Afresh");
                    clearInterval(timeoutInterval);
                    seeMore();
                    // $(membersRow).removeClass("working");
                    sendSuggestedRequests(payload, newLength);
                } else {
                    $(membersRow[users[i].uiPos]).addClass("loading_w");
                }
            }, rand * 1000);
        } else {
            console.log("Users not found recalling Function");
            scrollToPos(membersRow[(rowLength - 5)]);
            if (suggestedReqStatus) {
                var t = setTimeout(function () {
                    console.log("Recalled Function");
                    seeMore();
                    clearTimeout(t);
                    // $(membersRow).removeClass("working");
                    sendSuggestedRequests(payload, newLength);
                }, 1000);
            } else {
                stopSuggestedRequests();
            }
            // sendSuggestedRequests(payload, newLength);
        }
    });
}

const stopSuggestedRequests = () => {
    suggestedReqStatus = 0;
    console.log("Stop Interval Triggered", timeoutInterval);
    setTimeout(function () {
        $(".friendBrowserListUnit").removeClass("loading_w");
    }, 200);
    window.clearInterval(timeoutInterval);
    port.postMessage({action: "enableRunSF"});
    taostID.reset();
};

const seeMore = () => {
    var seeMoreEl = $(".uiMorePagerPrimary");
    var len = seeMoreEl.length;
    //console.log("See More Button Length",seeMoreEl);
    if (len) {
        if (seeMoreEl[len - 1].innerText.toLowerCase() == "show more") {
            seeMoreEl[len - 1].click();
        }
    }
};
/* ---------------- END OF FUNCTIONS FOR SEND REQUESTS TO FB SUGGESTIONS ---------------  */

/* --------- COMMON FUNCTIONS FOR GROUP MEMBERS & FRIENDS FRIEND LIST --------- */
const scrollToPos = el => {
    $("html,body").animate({
        scrollTop: $(el).offset().top - 15
    }, "slow");
};

const layerCancelOrConfirm = () => {
    console.log("Confirmation Popup");
    const cancel = $(".layerCancel");
    const confirm = $(".layerConfirm");
    const dialogConfirm = $('body').find(".layerConfirm");
    if (confirm.length || cancel.length) {
        setTimeout(function () {
            dialogConfirm.click();
            if (confirm.length) {
                confirm[confirm.length - 1].click();
            } else if (cancel.length) {
                cancel[cancel.length - 1].click();
            }
        }, 1000);
    }
};

const notifyUser = (payload, notif, count = 0) => {
    console.log("Notify User payload", payload);
    const sentCount = count;
    const param = {
        action: "notify",
        badge: {
            tabID: payload.tabID,
            text: sentCount.toString(),
        }
    };
    if (notif) {
        param.notification = notif;
        param.notifID = 'GroupMemberRequest'
    }
    port.postMessage(param);
};

const toast = (heading, body, type = 1, isSticky = false) => {
    var toastType = ["error", "success", "info", "warning"];
    const options = {
        heading: heading,
        text: body,
        showHideTransition: "slide",
        icon: toastType[type],
        position: "bottom-left"
    };
    if (isSticky) {
        options.hideAfter = isSticky;
    }
    return $.toast(options);
};

const simulateClick = (frndBtn) => {
    // $(frndBtn).css("background-color","red");
    $(frndBtn).click();
};

const randomIntFromInterval = (min, max) => { // min and max included
    return (Math.random() * (max - min + 1) + min) * 1000;
};


/* --------- END OF COMMON FUNCTIONS --------- */
